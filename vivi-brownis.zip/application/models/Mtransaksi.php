<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mtransaksi extends CI_Model {

	function getdata()
	{
		$query=$this->db->query("SELECT * FROM tbltransaksi ");
		return $query->result();
	}

	function getjadwallapangan()
	{
		$this->db->where('status', 'Ready');
		$query=$this->db->get("tbllapangan");
		return $query->result();
	}

	function insert($data){
		$this->db->insert('tbltransaksi',$data);
	}

	function update($data){
		$where = $this->input->post('idtransaksi',true);
		$this->db->where('idtransaksi', $where);
		$this->db->update('tbltransaksi', $data);
	}

	function getdataedit($id)
	{
		$this->db->where('idtransaksi', $id);
		$query=$this->db->get("tbltransaksi");
		return $query->result();
	}

	// function updaterecords($idsatuan,$namasatuan)
	// {
	// 	$query=" UPDATE tblstock SET namasatuan = '".$namasatuan."' WHERE idsatuan = '".$idsatuan."' ";
	// 	$this->db->query($query);
	// }

	// function deleterecords($idsatuan)
	// {
	// 	$query=" Delete from tblstock WHERE idsatuan = '".$idsatuan."' ";
	// 	$this->db->query($query);
	// }


}

/* End of file Mtransaksi.php */
/* Location: ./application/models/Mtransaksi.php */