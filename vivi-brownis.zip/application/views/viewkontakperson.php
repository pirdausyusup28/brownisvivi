    <div class="container-fluid bg-primary mb-5" style="background-color: #3e2e30 !important;">
      <div class="d-flex flex-column align-items-center justify-content-center"style="min-height: 400px">
        <h3 class="display-3 font-weight-bold text-white">Kontak Person</h3>
      </div>
    </div>
    <div class="container-fluid pt-5">
      <div class="container">
        <div class="text-center pb-2">
          <p class="section-title px-5">
            <span class="px-2">Bisa hubungi kami melalui : </span>
          </p>
          <!-- <h1 class="mb-4">Kontak kami seputar brownies nya</h1> -->
        </div>
        <div class="row">
          <div class="col-lg-12 mb-5 ">
            <div class="d-flex">
              <i
                class="fa fa-map-marker-alt d-inline-flex align-items-center justify-content-center bg-primary text-secondary rounded-circle"
                style="width: 45px; height: 45px"
              ></i>
              <div class="pl-3">
                <h5>Alamat</h5>
                <p>Jln Jatimakmur Kec Pondokgede Kab. Bekasi</p>
              </div>
            </div>
            <div class="d-flex">
              <i
                class="fa fa-envelope d-inline-flex align-items-center justify-content-center bg-primary text-secondary rounded-circle"
                style="width: 45px; height: 45px"
              ></i>
              <div class="pl-3">
                <h5>Email</h5>
                <p>vivibrownies@gmail.com</p>
              </div>
            </div>
            <div class="d-flex">
              <i
                class="fa fa-phone-alt d-inline-flex align-items-center justify-content-center bg-primary text-secondary rounded-circle"
                style="width: 45px; height: 45px"
              ></i>
              <div class="pl-3">
                <h5>Telp</h5>
                <p>085763884756</p>
              </div>
            </div>
            <div class="d-flex">
              <i
                class="far fa-clock d-inline-flex align-items-center justify-content-center bg-primary text-secondary rounded-circle"
                style="width: 45px; height: 45px"
              ></i>
              <div class="pl-3">
                <h5>Buka Jam</h5>
                <strong>Setiap Hari</strong>
                <p class="m-0">06:00  - 21:00 </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>