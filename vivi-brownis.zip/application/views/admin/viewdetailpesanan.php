<?php foreach ($pesanan as $p): ?>

<?php endforeach ?>
<section class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Form Detail Pesanan</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">Form Detail Pesanan</a></li>
                            <li class="breadcrumb-item"><a href="#!">Form Detail Pesanan</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
        <div class="row">
            <div class="col-sm-12">

            </div>
            <!-- [ form-element ] start -->
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Form Detail Pesanan</h5>
                    </div>
                    <div class="card-body">
                    <center><img  src="<?= base_url('images/'); ?><?= $p->gambar ?>" style="width: 350px;height: 300px"><br>Gambar Produk</center><br><br><hr>
                        <div class="row">
                            <div class="col-md-6">
                            
                                <form>
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">ID Pesanan</label>
                                        <div class="col-sm-3">
                                            <input type="text" name="idpesanan" id="idpesanan" class="form-control" value="<?= $p->idpesanan ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">ID Produk</label>
                                        <div class="col-sm-3">
                                            <input type="text" name="id" id="id" class="form-control" value="<?= $p->id ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Jenis Produk</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="jenisproduk" id="jenisproduk" class="form-control" value="<?= $p->jenisproduk ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Nama Pemesan</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="nama" id="nama" class="form-control" value="<?= $p->nama ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Harga</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="harga" id="harga" class="form-control" value="<?= $p->harga ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Tanggal Pesanan</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="tanggalpesan" id="tanggalpesan" class="form-control" value="<?= $p->tanggalpesan ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Metode Pembayaran</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="metodepembayaran" id="metodepembayaran" class="form-control" value="<?= $p->metodepembayaran ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Tenor Cicilan</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="cicilan" id="cicilan" class="form-control" value="<?= $p->cicilan ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Status Pesanan</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="statuspesanan" id="statuspesanan" class="form-control" value="<?= $p->statuspesanan ?>" readonly>
                                        </div>
                                    </div>
                                </form>
								<?php if ($p->statuspesanan == 'Pesanan Dikirim'): ?>
									<table class="table table-striped">
										<tr>
											<th>Cicilan ke</th>
											<th>Total</th>
											<th>No Ref Pembayaran</th>
											<th></th>
										</tr>
										<tr>
											<td>1</td>
											<td>Rp. 79.000</td>
											<td>1000003034500</td>
											<td><button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModalCenter" disabled>Sudah Bayar</button></td>
										</tr>
										<tr>
											<td>2</td>
											<td>Rp. 79.000</td>
											<td>-</td>
											<td><button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModalCenter">Belum Bayar</button></td>
										</tr>
										<tr>
											<td>3</td>
											<td>Rp. 79.000</td>
											<td>-</td>
											<td><button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModalCenter">Belum Bayar</button></td>
										</tr>
									</table>
									<?php endif ?>
								<div class="form-group row">
                                        <div class="col-sm-10">
                                            <?php if ($p->statuspesanan == 'Sedang Di Proses'): ?>
                                                <a href="<?= base_url('Admin/statuspesanandikirim/'); ?><?= $p->idpesanan ?>" class="btn btn-primary">Kirim Barang ke Customer</a>
											<?php elseif ($p->statuspesanan == 'Barang Dikirim'): ?>
                                                <a href="<?= base_url('Admin/statuspesananselesai/'); ?><?= $p->idpesanan ?>" class="btn btn-primary">Pesanan Selesi</a>
                                            <?php else: ?>
                                                <?php if($p->cicilan == ''){
                                                    $cil = '0';
                                                }else{
                                                    $cil = $p->cicilan;
                                                }?>
                                                <a href="<?= base_url('Admin/statuspesanan/'); ?><?= $p->idpesanan ?>/<?= $cil ?>" class="btn btn-primary">Proses Pesanan</a>
                                            <?php endif ?>
                                        </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <!-- <p style="color: red"><i>Gambar dari Customer</i></p><br> -->
                                <table class="table table-striped table-bordered table-sm">
                                    <tr class="text-center">
                                        <!-- <th>NO</th> -->
                                        <th>CICILAN KE</th>
                                        <th>TOTAL</th>
                                        <th>NO REF</th>
                                        <th></th>
                                    </tr>
                                    <?php
                                        $totalcicilan = $p->harga/$p->cicilan;
                                    ?>
                                    <?php foreach ($cicilan as $pp): ?>
                                    <tr class="text-center">
                                        <td><?= $pp->cicilanke?></td>
                                        <td>Rp. <?= number_format($totalcicilan) ?></td>
                                        <td>
                                            <input type="hidden" value="<?= $pp->id?>" id="idnoref<?= $pp->id?>" name="idnoref<?= $pp->id?>" />
                                            <input type="text" class="form-control" id="noref<?= $pp->id?>" name="noref<?= $pp->id?>" value="<?= $pp->norefpembayaran?>"></td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm" name="norefinput<?= $pp->id?>" id="norefinput<?= $pp->id?>" onclick="simpanref(<?= $pp->id?>)">Simpan No Ref</button></td>
                                    </tr>
                                    <?php endforeach ?>
                                </table>
                            </div>
                        </div>
						<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
						<div class="modal-dialog modal-dialog-centered" role="document">
							<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLongTitle">Masukan No Ref Pembayaran</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Masukan No Ref Pembayaran" required>
								</div>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								<button type="button" class="btn btn-primary">Save changes</button>
							</div>
							</div>
						</div>
						</div>
                        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
                        <script>
                            (function() {
                                'use strict';
                                window.addEventListener('load', function() {
                                    var forms = document.getUserByClassName('needs-validation');
                                    var validation = Array.prototype.filter.call(forms, function(form) {
                                        form.addEventListener('submit', function(event) {
                                            if (form.checkValidity() === false) {
                                                event.preventDefault();
                                                event.stopPropagation();
                                            }
                                            form.classList.add('was-validated');
                                        }, false);
                                    });
                                }, false);
                            })();
                            
                            function simpanref(id)
                            {
                                console.log(id);
                                // e.preventDefault();
                                // console.log($("#idnore"+idnorefs).val());
                                var idnoref = $("#idnoref"+id).val();
                                var noref = $("#noref"+id).val();
                                $.post("<?= base_url('Admin/simpannoref') ?>", {idnoref:idnoref, noref:noref}, function() {
                                    alert("No Ref Pembayaran Berhasil disimpan");
                                    location.reload();
                                });
                            }
                            $(document).ready(function () {
                                // var idnorefs = $("#idnoref").val();
                                // $("#norefinput"+idnorefs).click(function (e) { 
                                    // e.preventDefault();
                                    // console.log($("#idnore"+idnorefs).val());
                                    // var idnoref = $("#idnoref"+idnorefs).val();
                                    // var noref = $("#noref"+idnorefs).val();
                                    // $.post("<?= base_url('Admin/simpannoref') ?>", {idnoref:idnoref, noref:noref}, function() {
                                    //     // location.reload();
                                    // });
                                    
                                // });
                            });
                        </script>
            </div>
        </div>
    </div>
</section>
