<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pesanan</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<p style="text-align:center;;font-size:16px"><b>Laporan Pesanan</b></p>
<br>

<table class="table table-striped table-bordered table-sm">
    <thead>
        <tr>
            <th>#</th>
            <th>ID Pesanan</th>
            <th>ID Produk</th>
            <th>Nama Pemesan</th>
            <th>Jenis Produk</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Tanggal Pesanan</th>
            <th>Status Pesanan</th>
        </tr>
    </thead>
    <tbody>
        <?php $no=1; foreach ($pesanan as $p): ?>

        <tr>
            <td><?= $no++ ?></td>
            <td><?= $p->idpesanan ?></td>
            <td><?= $p->id ?></td>
            <td><?= $p->nama ?></td>
            <td><?= $p->jenisproduk ?></td>
            <td><?= $p->namaproduk ?></td>
            <td><?= $p->harga ?></td>
            <td><?= $p->tanggalpesan ?></td>
            <td><?= $p->statuspesanan ?></td>
        </tr>
    <?php endforeach ?>
</tbody>
</table>
</body>
</html>
