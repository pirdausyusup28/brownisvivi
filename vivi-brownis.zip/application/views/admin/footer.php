    <!-- Required Js -->
    <script src="<?= base_url(); ?>assets/assetsadmin/js/vendor-all.min.js"></script>
    <script src="<?= base_url(); ?>assets/assetsadmin/js/plugins/bootstrap.min.js"></script>
    <script src="<?= base_url(); ?>assets/assetsadmin/js/ripple.js"></script>
    <script src="<?= base_url(); ?>assets/assetsadmin/js/pcoded.js"></script>
</body>
</html>
