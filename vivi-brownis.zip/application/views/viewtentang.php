<div class="container-fluid bg-primary mb-5" style="background-color: #3e2e30 !important;">
	<div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 400px">
		<h3 class="display-3 font-weight-bold text-white">Tentang Brownies By Vivi</h3>
	</div>
</div>
<div class="container-fluid py-5">
	<div class="container">
	<div class="row align-items-center">
		<div class="col-lg-5">
		<img class="img-fluid rounded mb-5 mb-lg-0" src="<?= base_url();?>assets/assets/img/kue1.jpg" alt=""
		/>
		</div>
		<div class="col-lg-7">
		<p class="section-title pr-5">
			<span class="pr-2">Brownies By Vivi</span>
		</p>
		<h1 class="mb-4">Berdiri pada tahun 2023</h1>
		<p>
			merupakan toko brownies yang sudah membuka cabang di seluruh indonesia......
		</p>
		</div>
	</div>
	</div>
</div>