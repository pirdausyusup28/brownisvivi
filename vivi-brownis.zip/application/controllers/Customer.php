<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Mcustomer');
	}

	public function index()
	{
		$data['produk'] = $this->Mcustomer->getproduk();
        $this->load->view('menu');
		$this->load->view('viewhome',$data);
        $this->load->view('footer');
	}

	public function menu()
	{
		$data['produk'] = $this->Mcustomer->getproduk();
        $this->load->view('menu');
		$this->load->view('viewmenu',$data);
        $this->load->view('footer');
	}

	public function tentang()
	{
		$data['produk'] = $this->Mcustomer->getproduk();
        $this->load->view('menu');
		$this->load->view('viewtentang',$data);
        $this->load->view('footer');
	}

	public function kontakperson()
	{
		$data['produk'] = $this->Mcustomer->getproduk();
        $this->load->view('menu');
		$this->load->view('viewkontakperson',$data);
        $this->load->view('footer');
	}

	public function Order()
	{
		// $data['produk'] = $this->Mcustomer->getprodukorder();
        $this->load->view('menu');
		$this->load->view('vieworderproduk');
        $this->load->view('footer');
	}

	public function preorder()
	{
		$data['produk'] = $this->Mcustomer->getprodukpreorder();
        $this->load->view('menu');
		$this->load->view('viewhome',$data);
	}

	public function pesanan()
	{
		$nama = $this->session->userdata('username');
		$data['pesanan'] = $this->Mcustomer->getpesanan($nama);
        $this->load->view('menu');
		$this->load->view('viewpesanan',$data);
	}

	public function cicilan($id)
	{
		// echo $id;
		// die();
		$data['cicilan'] = $this->Mcustomer->getcicilan($id);
		// var_dump($data['cicilan']);
		// die();
		$data['tenor'] = $this->Mcustomer->gettenor($id);
        $this->load->view('menu');
		$this->load->view('viewcicilan',$data);
	}

	public function informasicicilan($id){
		$data["cicilan"] = $this->Mcustomer->getcicilanpertama($id);
		$this->load->view('menu');
		$this->load->view('informasicicilan',$data);
	}

}

/* End of file Customer.php */
/* Location: ./application/controllers/Customer.php */
